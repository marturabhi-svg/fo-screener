import React, { useState, useMemo } from 'react';
import Papa from 'papaparse';
import { saveAs } from 'file-saver';

export default function App() {
  const [priceRows, setPriceRows] = useState([]);
  const [futRows, setFutRows] = useState([]);
  const [priceMapping, setPriceMapping] = useState({ symbol: 'symbol', date: 'date', open: 'open', high: 'high', low: 'low', close: 'close', volume: 'volume' });
  const [futMapping, setFutMapping] = useState({ symbol: 'symbol', date: 'date', oi: 'oi', fut_price: 'fut_price' });
  const [results, setResults] = useState([]);
  const [messages, setMessages] = useState([]);

  function parseCSVFile(file, onData) {
    if (!file) return;
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (res) => {
        onData(res.data);
      },
      error: (err) => {
        setMessages(m => [...m, 'CSV parse error: ' + err.message]);
      }
    });
  }

  function handlePriceUpload(e) {
    const f = e.target.files[0];
    parseCSVFile(f, (data) => setPriceRows(data));
  }

  function handleFutUpload(e) {
    const f = e.target.files[0];
    parseCSVFile(f, (data) => setFutRows(data));
  }

  function normalizeDate(d) {
    if (!d) return null;
    const parsed = new Date(d);
    if (!isNaN(parsed)) return parsed.toISOString().slice(0,10);
    return null;
  }

  function buildIndex(rows, mapping) {
    const idx = {};
    rows.forEach(r => {
      const sym = (r[mapping.symbol] || r['symbol'] || r['ticker'] || '').toString().trim();
      const date = normalizeDate(r[mapping.date] ?? r['date']);
      if (!sym || !date) return;
      if (!idx[sym]) idx[sym] = {};
      idx[sym][date] = r;
    });
    return idx;
  }

  function toNumber(x) {
    if (x === undefined || x === null || x === '') return NaN;
    const n = Number(String(x).replace(/[, ]+/g, ''));
    return isNaN(n) ? NaN : n;
  }

  function runScreener() {
    setMessages([]);
    const priceIdx = buildIndex(priceRows, priceMapping);
    const futIdx = buildIndex(futRows, futMapping);

    const allSymbols = new Set([...Object.keys(priceIdx), ...Object.keys(futIdx)]);
    const out = [];

    allSymbols.forEach(sym => {
      const pSeries = priceIdx[sym] || {};
      const fSeries = futIdx[sym] || {};
      const dates = Object.keys(pSeries).sort();
      if (dates.length < 3) return;

      const latestDate = dates[dates.length-1];
      const prevDate = dates[dates.length-2];
      const recentDates = dates.slice(-6);
      const vols = recentDates.map(d => toNumber(pSeries[d]?.[priceMapping.volume] ?? pSeries[d]?.volume)).filter(v => !isNaN(v));
      if (vols.length === 0) return;
      const vol5 = vols.reduce((a,b)=>a+b,0) / vols.length;

      const latest = pSeries[latestDate];
      const prev = pSeries[prevDate];
      if (!latest || !prev) return;
      const latestClose = toNumber(latest[priceMapping.close] ?? latest.close);
      const prevHigh = toNumber(prev[priceMapping.high] ?? prev.high);
      const latestVolume = toNumber(latest[priceMapping.volume] ?? latest.volume);
      const latestHigh = toNumber(latest[priceMapping.high] ?? latest.high);

      const condA = latestClose > prevHigh;
      const condB = latestVolume > 2 * vol5;
      const condE = latestClose >= (latestHigh * 0.98);

      const fLatest = fSeries[latestDate];
      const fPrev = fSeries[prevDate];

      let condC = false;
      if (fLatest && fPrev) {
        const fLatestOI = toNumber(fLatest[futMapping.oi] ?? fLatest.oi);
        const fPrevOI = toNumber(fPrev[futMapping.oi] ?? fPrev.oi);
        const fLatestPrice = toNumber(fLatest[futMapping.fut_price] ?? fLatest.fut_price);
        const fPrevPrice = toNumber(fPrev[futMapping.fut_price] ?? fPrev.fut_price);
        if (!isNaN(fLatestOI) && !isNaN(fPrevOI) && !isNaN(fLatestPrice) && !isNaN(fPrevPrice)) {
          const longBuild = (fLatestOI > fPrevOI) && (fLatestPrice > fPrevPrice);
          const shortCover = (fLatestOI < fPrevOI) && (fLatestPrice > fPrevPrice);
          condC = longBuild || shortCover;
        }
      }

      if (condA && condB && condC && condE) {
        out.push({ symbol: sym, latestDate, latestClose, prevHigh, latestVolume, vol5, latestHigh });
      }
    });

    setResults(out);
    if (out.length === 0) setMessages(['No symbols matched the screener with the provided data.']);
  }

  function downloadResults() {
    if (results.length === 0) return;
    const csv = Papa.unparse(results);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    saveAs(blob, 'screener_results.csv');
  }

  const samplePriceHeader = useMemo(() => Object.keys(priceRows[0] || {}).slice(0,10).join(', '), [priceRows]);
  const sampleFutHeader = useMemo(() => Object.keys(futRows[0] || {}).slice(0,10).join(', '), [futRows]);

  return (
    <div style={{fontFamily:'Arial, Helvetica, sans-serif', padding:20, maxWidth:1000, margin:'0 auto'}}>
      <h1>F&O Screener</h1>
      <p>Upload Price CSV (OHLCV) and Futures OI CSV. Map columns if needed, then click Run Screener.</p>

      <div style={{display:'flex', gap:20, flexWrap:'wrap'}}>
        <div style={{flex:1, minWidth:300, border:'1px solid #ddd', padding:12, borderRadius:8}}>
          <h3>Price CSV (OHLCV)</h3>
          <input type="file" accept=".csv,text/csv" onChange={handlePriceUpload} />
          <div style={{marginTop:8, fontSize:12, color:'#555'}}>Sample headers: {samplePriceHeader || 'no file uploaded'}</div>
          <div style={{marginTop:8}}>
            {['symbol','date','open','high','low','close','volume'].map(k => (
              <div key={k} style={{display:'flex', gap:8, alignItems:'center', marginTop:6}}>
                <div style={{width:80}}>{k}</div>
                <input style={{flex:1,padding:6}} value={priceMapping[k]} onChange={e=>setPriceMapping(m=>({...m,[k]:e.target.value}))} />
              </div>
            ))}
          </div>
        </div>

        <div style={{flex:1, minWidth:300, border:'1px solid #ddd', padding:12, borderRadius:8}}>
          <h3>Futures OI CSV</h3>
          <input type="file" accept=".csv,text/csv" onChange={handleFutUpload} />
          <div style={{marginTop:8, fontSize:12, color:'#555'}}>Sample headers: {sampleFutHeader || 'no file uploaded'}</div>
          <div style={{marginTop:8}}>
            {['symbol','date','oi','fut_price'].map(k => (
              <div key={k} style={{display:'flex', gap:8, alignItems:'center', marginTop:6}}>
                <div style={{width:80}}>{k}</div>
                <input style={{flex:1,padding:6}} value={futMapping[k]} onChange={e=>setFutMapping(m=>({...m,[k]:e.target.value}))} />
              </div>
            ))}
          </div>
        </div>
      </div>

      <div style={{marginTop:16, display:'flex', gap:10}}>
        <button onClick={runScreener} style={{padding:'8px 12px', background:'#0b74de', color:'#fff', border:'none', borderRadius:6}}>Run Screener</button>
        <button onClick={()=>{ setPriceRows([]); setFutRows([]); setResults([]); setMessages([]); }} style={{padding:'8px 12px', borderRadius:6}}>Reset</button>
        <button onClick={downloadResults} style={{padding:'8px 12px', background:'#16a34a', color:'#fff', border:'none', borderRadius:6}}>Export Results</button>
      </div>

      <div style={{marginTop:12}}>
        {messages.map((m,i)=>(<div key={i} style={{color:'red'}}>{m}</div>))}
      </div>

      <div style={{marginTop:16}}>
        <h3>Results ({results.length})</h3>
        <div style={{overflowX:'auto'}}>
          <table style={{width:'100%', borderCollapse:'collapse'}}>
            <thead style={{background:'#f3f4f6'}}>
              <tr>
                <th style={{textAlign:'left', padding:8}}>Symbol</th>
                <th style={{textAlign:'left', padding:8}}>Date</th>
                <th style={{textAlign:'right', padding:8}}>Close</th>
                <th style={{textAlign:'right', padding:8}}>Prev High</th>
                <th style={{textAlign:'right', padding:8}}>Volume</th>
                <th style={{textAlign:'right', padding:8}}>5d Avg Vol</th>
              </tr>
            </thead>
            <tbody>
              {results.map(r => (
                <tr key={r.symbol} style={{borderTop:'1px solid #e5e7eb'}}>
                  <td style={{padding:8}}>{r.symbol}</td>
                  <td style={{padding:8}}>{r.latestDate}</td>
                  <td style={{padding:8, textAlign:'right'}}>{r.latestClose}</td>
                  <td style={{padding:8, textAlign:'right'}}>{r.prevHigh}</td>
                  <td style={{padding:8, textAlign:'right'}}>{r.latestVolume}</td>
                  <td style={{padding:8, textAlign:'right'}}>{Math.round(r.vol5)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div style={{marginTop:18, fontSize:12, color:'#555'}}>
        Note: This runs locally in your browser on uploaded CSV files. For automatic live data, backend integration is required.
      </div>
    </div>
  );
}
